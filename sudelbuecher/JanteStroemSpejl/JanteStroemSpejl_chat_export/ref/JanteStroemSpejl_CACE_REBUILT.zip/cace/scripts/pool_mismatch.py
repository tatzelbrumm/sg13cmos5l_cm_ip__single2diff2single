def postprocess(results, conditions):
    pooled = []
    for k in range(1, 11):
        values = results[f"e{k:02d}"]
        if isinstance(values, (list, tuple)):
            pooled.extend(float(v) for v in values)
        else:
            pooled.append(float(values))
    return {"error_all": pooled}
